const express = require("express")
const app = express();
const bodyParser = require('body-parser');
const port = 3000;
const studentRouter = require("./students/students.route")
const path = require("path")
const readStudentsDB = require("./students/read.Students")

app.use(bodyParser.urlencoded({ extended: true}));
app.use(express.static('../Client/public'))
app.use(readStudentsDB)


app.get('/',  async function(req,res){
    const homeHTML = path.join(__dirname,'../Client/Homepage.html')
    await res.sendFile(homeHTML )
});
app.use("/", studentRouter)
app.all("*",(req,res,)=>{
    res.status(404).send("404 page does not exists")
})





app.listen(port, function(req,res){
    console.log("server is active port http://localhost:3000")
})