const path = require("path")

const login =(req,res) => {
    const loginHTML = path.join(__dirname, "../../Client/login.html")
    res.sendFile(loginHTML)
}


const payment = (req,res) => {
    const paymentHTML = path.join(__dirname, "../../Client/payment.html")
    res.sendFile(paymentHTML)
}



const assignment = (req,res) => {
    const assignmentHTML = path.join(__dirname, "../../Client/assignment.html")
    res.sendFile(assignmentHTML)
}


const courseRegistration =(req,res) => {
    const courseRegHTML = path.join(__dirname, "../../Client/course-registration.html")
    res.sendFile(courseRegHTML)
}


const redirectToPayment = (req,res) =>{
    const paymentHTML = path.join(__dirname, "../../Client/payment.html")
    res.redirect("/payment.html")
}

// const redirectToCourseReg = (req,res) =>{
//     const courseRegHTML = path.join(__dirname, "'../../Client/course-registration.html")
//     res.redirect(courseRegHTML)
// }

module.exports = {
    login,
    payment,
    assignment,
    courseRegistration,
    redirectToPayment
}