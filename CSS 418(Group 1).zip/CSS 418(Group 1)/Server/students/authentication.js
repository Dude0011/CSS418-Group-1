   function authenticate(req,res,next){
    const {email, password} = req.body;

     console.log(email, password)
    const registeredUsers = JSON.parse(req.readUsers);
    
    let validUser = registeredUsers.find(user => email === user.email)
    if (!validUser){
      res.status(401).json("Enter username and password")
    }

    if( validUser.password !== password){
      res.status(401).json("Wrong username or password")
    }

      res.status(200).json("Login successful")
    
  }


  module.exports = authenticate