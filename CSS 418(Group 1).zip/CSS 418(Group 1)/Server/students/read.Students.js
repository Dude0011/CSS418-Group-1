const fs = require('fs');
const path = require('path');
const userPath = path.join(__dirname,"/students.json");

const readUsersJson = (req,res,next) => {
    fs.readFile(userPath, "utf-8", (err,data)=>{
        if(err){
            console.error('Error reading User', err);
            res.status(500).send("Internal Server error");
            return;
        }
             req.readUsers = data;
             next();     
    })
};

module.exports = readUsersJson
