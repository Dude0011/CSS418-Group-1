const express = require("express");
const router = express.Router();

const {
    payment,
    assignment,
    courseRegistration,
    login,
    redirectToPayment
   
}   = require("./students.controller")

const authentication = require("./authentication");

router.get("/assignment", assignment );
router.get("/payment.html", payment )
router.get("/login.html",login)
router.post("/login.html",authentication, redirectToPayment)
router.get("/course-registration.html", courseRegistration)


module.exports = router